import unittest, csv, gzip, json, hashlib, collections
from pathlib import Path
ROOT=Path(__file__).parent
CENSUS=ROOT/'finalrun'
REG=Path('/mnt/data/xgba_work/v12/XGBA_Mapping_Register_v1.2_11024.csv')
CONTRACTS=Path('/mnt/data/xgba_work/v14/consolidated_semantic_contracts.json')
def load(name):
 with gzip.open(CENSUS/name,'rt',encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
class Integration(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.manifest=load('tracked_file_manifest.csv.gz');cls.idx={(r['repo'],r['path']):r for r in cls.manifest}
  with REG.open() as f:cls.reg=list(csv.DictReader(f))
  cls.queue=load('semantic_review_queue.csv.gz')
  cls.lex=load('lexical_sites.csv.gz')
  cls.inc=load('resolved_include_edges.csv.gz')
  cls.summ=json.loads((CENSUS/'second_pass_summary.json').read_text())
  cls.cens=json.loads((CENSUS/'audit_summary.json').read_text())
 def test_pinned_manifest(self):
  self.assertEqual(len(self.idx),14834);self.assertTrue(self.cens['census_complete'])
 def test_original_mapping_integrity(self):
  self.assertEqual(len(self.reg),11024)
  for x in self.reg:
   y=self.idx[x['repo'],x['path']]
   self.assertEqual(x['source_blob_sha'],y['blob_sha'])
   self.assertEqual(x['revision'],y['revision'])
 def test_original_mapping_unique(self):
  self.assertEqual(len({x['record_id'] for x in self.reg}),len(self.reg))
 def test_dossier_manifest_coverage(self):
  self.assertEqual(len(self.queue),len(self.manifest))
  self.assertEqual({(x['repo'],x['path']) for x in self.queue},set(self.idx))
 def test_all_source_blobs_sha_verified(self):
  self.assertEqual(self.summ['source_blobs_sha1_verified'],4685)
  self.assertEqual(self.summ['source_blobs_sha1_verified'],sum(x['category'] in ('source','structured_or_text_config') for x in self.manifest))
 def test_lexical_sites_provenance(self):
  self.assertEqual(len(self.lex),5711)
  for x in self.lex:
   self.assertEqual(x['blob_sha'],self.idx[x['repo'],x['path']]['blob_sha'])
 def test_include_total_and_status(self):
  self.assertEqual(len(self.inc),13729)
  self.assertEqual(sum(self.summ['include_edges'].values()),len(self.inc))
 def test_dossier_evidence_integrity(self):
  n=0
  with gzip.open(CENSUS/'candidate_review_dossiers.jsonl.gz','rt',encoding='utf-8') as f:
   for doc,row in zip(f,self.queue):
    d=json.loads(doc)
    compact=json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=True)
    self.assertEqual(hashlib.sha256(compact.encode()).hexdigest(),row['evidence_sha256'])
    self.assertEqual(d['provenance']['git_blob_sha'],row['blob_sha'])
    self.assertFalse(d['review']['semantic_signoff'])
    n+=1
  self.assertEqual(n,len(self.queue))
 def test_earlier_contract_anchors_all_exist(self):
  contracts=json.loads(CONTRACTS.read_text())['contracts'];self.assertEqual(len(contracts),30)
  for c in contracts:
   for anchor in c['source_locations']:
    self.assertIn((c['owner_repo'],anchor['path']),self.idx)
 def test_semantic_gate_fails_closed(self):
  self.assertFalse(self.summ['phase1_semantic_mapping_complete'])
  self.assertEqual(self.summ['semantic_signoff_count'],0)
 def test_unresolved_classification_totals(self):
  j=json.loads((CENSUS/'include_classification_summary.json').read_text())
  self.assertEqual(sum(j['candidate_classification'].values()),j['unresolved_includes_total'])
  self.assertFalse(j['semantic_resolution_verified'])
if __name__=='__main__':unittest.main(verbosity=2)
