#!/usr/bin/env python3
"""Conservatively append distinct, pinned census line candidates without renumbering old mapping records."""
import csv,gzip,json,hashlib,collections,argparse
from pathlib import Path
from itertools import groupby
FIELDS=['record_id','record_type','repo','revision','path','line','source_url','source_blob_sha','category','origin_symbol','target_symbol','discovery_method','confidence','review_status','notes']
def digest(path):
 s=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''):s.update(chunk)
 return s.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--existing',type=Path,required=True);p.add_argument('--census',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 a.out.mkdir(parents=True,exist_ok=True)
 with a.existing.open(newline='',encoding='utf-8') as f:r=list(csv.DictReader(f))
 assert list(r[0])==FIELDS
 oldids={x['record_id'] for x in r};assert len(oldids)==len(r)==11024
 with gzip.open(a.census/'tracked_file_manifest.csv.gz','rt',encoding='utf-8') as f:manifest={(z['repo'],z['path']):z for z in csv.DictReader(f)}
 with gzip.open(a.census/'lexical_sites.csv.gz','rt',encoding='utf-8') as f:found=list(csv.DictReader(f))
 oldpositions={(z['repo'],z['path'],int(z['line'])) for z in r if z['line'].isdigit()}
 for z in r:
  m=manifest[z['repo'],z['path']];assert z['revision']==m['revision'] and z['source_blob_sha']==m['blob_sha'],(z['repo'],z['path'])
 groups=collections.defaultdict(list)
 for z in found:
  key=z['repo'],z['path'],int(z['line']);m=manifest[key[:2]]
  assert z['blob_sha']==m['blob_sha'] and 1<=key[2]<=int(m['source_lines'])
  if key not in oldpositions:groups[key].append(z)
 # Preserve discovery order from whole-tree stable scan, then source line position.
 new=[]
 for n,k in enumerate(sorted(groups),1):
  vs=groups[k]
  m=manifest[k[:2]];rules=sorted({z['rule'] for z in vs});snippet=vs[0]['excerpt']
  record={
   'record_id':f'XC15-{n:05d}', 'record_type':'source_candidate',
   'repo':k[0], 'revision':m['revision'], 'path':k[1], 'line':str(k[2]),
   'source_url':f'https://github.com/{k[0]}/blob/{m["revision"]}/{k[1]}#L{k[2]}',
   'source_blob_sha':m['blob_sha'], 'category':'+'.join('CENSUS_'+t.upper() for t in rules),
   'origin_symbol':'','target_symbol':'','discovery_method':'full_pinned_five_repo_census_v15',
   'confidence':'lexical_candidate','review_status':'requires_semantic_review',
   'notes':f'New lexical source-line candidate (NOT semantic proof). Rules: {", ".join(rules)}. Excerpt: {snippet[:220]}'
  }
  new.append(record)
 assert len(new)==len(groups) and all(z['record_id'] not in oldids for z in new)
 merged=r+new
 p=a.out/'XGBA_Mapping_Register_v1.5.csv'
 with p.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(merged)
 with (a.out/'XGBA_New_Lexical_Candidates_v1.5.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(new)
 steps=range(11500,len(merged)+1,500)
 out=[]
 for n in steps:
  prefix_ids=[x['record_id'] for x in merged[:n]]
  item={'checkpoint_total_records':n,'existing_records':min(11024,n),'new_census_candidates':max(0,n-11024),
   'last_record_id':prefix_ids[-1], 'id_manifest_sha256':hashlib.sha256('\n'.join(prefix_ids).encode()).hexdigest(),
   'semantically_approved_from_new_candidates':0}
  (a.out/f'mapping_checkpoint_{n:05d}.json').write_text(json.dumps(item,indent=2)+'\n');out.append(item)
 keys={(z['repo'],z['path']) for z in r};newkeys={(z['repo'],z['path']) for z in new}
 report={'original_records':len(r),'new_source_line_candidates':len(new),'total_mapping_records':len(merged),
         'new_distinct_source_files':len(newkeys-keys), 'distinct_mapped_files_total':len(keys|newkeys),
         'full_census_files':len(manifest),'mapping_positions_verified':len(new),'new_candidate_review_status':'requires_semantic_review',
         'mapping_gate':'FAIL_INCOMPLETE','sha256_merged_csv':digest(p),'checkpoint_records':[x['checkpoint_total_records'] for x in out]}
 (a.out/'mapping_merge_report_v15.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
