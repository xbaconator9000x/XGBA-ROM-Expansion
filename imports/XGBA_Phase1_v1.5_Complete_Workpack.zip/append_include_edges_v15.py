#!/usr/bin/env python3
"""Append full pinned-source #include directives as syntactic dependency candidates, not runtime/compile proofs."""
import csv,gzip,json,collections,hashlib,argparse
from pathlib import Path
FIELDS=['record_id','record_type','repo','revision','path','line','source_url','source_blob_sha','category','origin_symbol','target_symbol','discovery_method','confidence','review_status','notes']
def main():
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--census',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 with a.base.open('r',newline='',encoding='utf-8') as f:old=list(csv.DictReader(f))
 assert len(old)==15339 and list(old[0])==FIELDS
 with gzip.open(a.census/'tracked_file_manifest.csv.gz','rt') as f:manifest={(x['repo'],x['path']):x for x in csv.DictReader(f)}
 with gzip.open(a.census/'resolved_include_edges.csv.gz','rt') as f:includes=list(csv.DictReader(f))
 seen=set();added=[];dist=collections.Counter();files=set()
 for z in includes:
  k=z['repo'],z['from_path'],int(z['line']),z['include']
  assert k not in seen,('duplicate include directive',k)
  seen.add(k);m=manifest[k[:2]]
  assert 1<=k[2]<=int(m['source_lines'])
  target=z['target_path'] if z['target_path'] else z['include']
  record={'record_id':f'XC15I-{len(added)+1:05d}','record_type':'include_dependency_candidate',
    'repo':k[0],'revision':m['revision'],'path':k[1],'line':str(k[2]),
    'source_url':f'https://github.com/{k[0]}/blob/{m["revision"]}/{k[1]}#L{k[2]}',
    'source_blob_sha':m['blob_sha'],
    'category':'INCLUDE_'+z['resolution'],'origin_symbol':k[1], 'target_symbol':target,
    'discovery_method':'pinned_source_preprocessor_include_syntax_v15',
    'confidence':'syntactic_include_directive_only','review_status':'requires_build_include_semantic_review',
    'notes':f'Included token {k[3]!r}; path candidate resolution {z["resolution"]}; not proof of active compiler include path or runtime dependency.'}
  added.append(record);dist[z['resolution']]+=1;files.add(k[:2])
 assert len(added)==13729
 allrows=old+added
 dest=a.out/'XGBA_Mapping_Register_v1.5_Includes.csv'
 with dest.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(allrows)
 with (a.out/'XGBA_Include_Edge_Candidates_v1.5.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(added)
 checkpoints=[]
 for n in range(15500,len(allrows)+1,500):
  prefix='\n'.join(z['record_id'] for z in allrows[:n])
  item={'records':n,'new_include_candidates':max(0,n-len(old)), 'last_record_id':allrows[n-1]['record_id'],
    'record_id_prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest(),'include_semantic_signoffs':0}
  (a.out/f'mapping_checkpoint_{n:05d}.json').write_text(json.dumps(item,indent=2)+'\n');checkpoints.append(n)
 mapped_files={(z['repo'],z['path']) for z in allrows}
 report={'prior_mapping_records':len(old),'new_preprocessor_include_candidates':len(added),
  'total_mapping_records':len(allrows),'new_distinct_mapped_files':len(files-{(z['repo'],z['path']) for z in old}),
  'distinct_mapping_files_total':len(mapped_files),'include_resolution_counts':dict(dist),
  'semantic_signoff_count_for_new_includes':0,'mapping_gate':'FAIL_INCOMPLETE',
  'sha256_combined_csv':hashlib.sha256(dest.read_bytes()).hexdigest(), 'checkpoints':checkpoints}
 (a.out/'include_mapping_merge_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
