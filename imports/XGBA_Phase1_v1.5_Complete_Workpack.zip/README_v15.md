# XGBA / ROM Expansion — Phase 1 checkpoint v1.5

**DECISION: FAIL_INCOMPLETE. No expansion implementation authorized yet.**

## Verified source census and second-pass evidence

GitHub Actions succeeded on five exactly pinned upstream trees. Run 40159337299 published the complete review artifact. All 14,834 tracked source-tree objects are inventoried. Every one of 4,685 text source/config objects passed independent local Git-blob SHA verification and has a review dossier. Other 10,149 tracked objects (assets/docs/etc.) are inventoried but **not semantically approved**. Indexes include 5,711 lexical rule occurrences, 13,729 preprocessor include references, 8,315 symbol candidates, and 14,834 per-file machine evidence dossiers with provenance/evidence hashes.

New prioritized queue: 338 P0, 1,297 P1, 8,658 P2, and 4,541 P3. Heuristic priorities, not verified risk determinations. Poryscript source content checked as pinned. High-priority FireRed `src/load_save.c` was *not* recognized by the initial keyword scanner; new path-aware triage fixes its rank.

Include reference candidates: 8,676 single-path matches, 62 ambiguous, 4,991 unresolved. The unresolved references are provisionally broken down into 2,384 standard library, 1,015 Qt, 230 generated, 155 other third-party/platform, 698 local-name hypotheses and 509 unknown. Even one-path matches remain candidate relationships pending actual compiler/build-flag analysis.

## Reconciled cumulative mapping record register

All original v1.2 11,024 register rows were preserved without renumbering. **11,024/11,024** existing source paths, Git blob hashes and pinned revision strings match the verified full source census. The new complete source scan yielded **4,315 distinct source-line candidates** not present by `(repo,path,line)` in the old register; no same-position duplicates were added. Eight 500-record checkpoints cover 11,500–15,000.

Separately, all **13,729** `#include`-syntax references were added as typed syntactic dependency candidates with source line/hash and resolution hypothesis. Twenty-eight further 500-record checkpoints cover 15,500–29,000. **Final mapping record total 29,068**, referencing **2,631 distinct source files**. This is a *candidate/inventory coverage measure*, not proof that 29,068 behaviors are understood or cleared. New candidates carry explicit non-semantic review statuses.

## New targeted source contracts

Four targeted pinned source-anchored constraints were documented: mGBA savestate ROM CRC warning vs fatal game identity mismatch; remapping before CPU pipeline restoration; FireRed raw advancing script bytecode pointers; FireRed save-block relocation and encryption-key changes. They are credible targeted findings but not whole-file reviews or runtime tests.

## Gate and verification

Repository GitHub Actions workflow evaluates a fail-closed Phase 1 mapping gate on every run. Its verified current result is `FAIL_INCOMPLETE`, **0 signed file dispositions out of 14,834**. **11/11** independent local evidence integration tests and **18/18** preserved v1.4 offline tests passed. The source census and evidence pipeline ran on GitHub. Builds and emulator regression tests are not required for completing Phase 1 mapping, but are separately required before implementing/releasing an expansion.

The older full v1.4 archive, newest complete GitHub Actions evidence artifact, v1.5 merged registers/checkpoints, scripts, contracts and verification data are included in the complete download.

## Next requirements

- Independently review all tracked source/asset disposition categories; for each, record the source hash, actual dependencies, rationale and evidence with reviewed approval. Follow P0 first, and resolve generated and indirect dependency edges.
- Turn each risky resource / pointer / CPU / DMA / savestate / editor / build dependency into a versioned contract and prove the architecture's interface specification is exhaustive across the five pinned trees.
- Keep Phase 1 mapping and Phase 2 runtime/release gates strictly separate.

## Reproducibility

Repository: https://github.com/xbaconator9000x/XGBA-ROM-Expansion
Successful audited run: https://github.com/xbaconator9000x/XGBA-ROM-Expansion/actions/runs/40159337299
The GitHub Actions artifact is retained for 90 days and can be re-created via the committed scripts. Data included in this ZIP avoids dependence on that retention window.
